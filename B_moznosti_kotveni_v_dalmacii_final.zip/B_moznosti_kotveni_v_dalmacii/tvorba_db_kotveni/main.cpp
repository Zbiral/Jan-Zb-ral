#include <iostream>
#include <QCoreApplication>
#include <QDebug>
#include <QtSql>

using namespace std;

void ostrovy_db (int id_ostrov, QString nazev_ostrov);
void zatoky_db (int id_zatoka, int id_ostrov, QString nazev_zatoka);
void kotveni_db (int id_zatoka, QString molo, QString boje, QString kotva);
void sluzby_db (int id_zatoka, QString obchod, QString restaurace);

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    qDebug()<<"start";
    QSqlDatabase pristavy;
    pristavy= QSqlDatabase::addDatabase("QSQLITE");
    pristavy.setDatabaseName("../pristavy.db");
    if(!pristavy.open())
    {
        qDebug()<<"Databázi se nepodařilo otevřít.";
    }


    QString prikaz_1 = "CREATE TABLE ostrovy ( id_ostrov integer, nazev_ostrov VARCHAR(20) )";

    QSqlQuery query_1;

    if(!query_1.exec(prikaz_1))
    {
        qDebug()<<"Smaž předchozí databázi";
    }

    qDebug()<<"Příprava dat pro ostrovy provedena.";

    ostrovy_db(1,"Vis");
    ostrovy_db(2,"Šolta");
    ostrovy_db(3,"Brač");
    ostrovy_db(4,"Hvar");
    ostrovy_db(5,"Korčula");
    ostrovy_db(6,"Lastovo");
    ostrovy_db(7,"Mljet");
    ostrovy_db(8,"Plješac");
    ostrovy_db(9,"Pevnina");


    QString prikaz_2 = "CREATE TABLE zatoky (id_zatoka integer, id_ostrov integer, nazev_zatoka VARCHAR(20) )";

    QSqlQuery query_2;


    if(!query_2.exec(prikaz_2))
    {
        qDebug()<<"Smaž předchozí databázi";
    }

    qDebug()<<"Příprava dat pro zátoky provedena.";

    zatoky_db(1,1,"Vis");
    zatoky_db(2,1,"Rogačič");
    zatoky_db(3,1,"Gradac");
    zatoky_db(4,1,"Oključina");
    zatoky_db(5,1,"Komiža");
    zatoky_db(6,1,"Mala Travna");
    zatoky_db(7,1,"Vela Travna");
    zatoky_db(8,1,"Ruda");
    zatoky_db(9,1,"Rukavac");
    zatoky_db(10,1,"Milna");
    zatoky_db(11,1,"Stončica");
    zatoky_db(12,2,"Maslinica");
    zatoky_db(13,2,"D.Krušica");
    zatoky_db(14,2,"Rogač");
    zatoky_db(15,2,"Nečujam");
    zatoky_db(16,2,"Stomorska");
    zatoky_db(17,2,"G.Krušica");
    zatoky_db(18,2,"Livka");
    zatoky_db(19,2,"Senjska");
    zatoky_db(20,2,"Jorja");
    zatoky_db(21,2,"Tatinja");
    zatoky_db(22,2,"Zaglav");
    zatoky_db(23,2,"Poganica");
    zatoky_db(24,2,"Sešula");
    zatoky_db(25,3,"Milna");
    zatoky_db(26,3,"Bobovišče");
    zatoky_db(27,3,"Stiniva");
    zatoky_db(28,3,"Stipanska");
    zatoky_db(29,3,"Sutivan");
    zatoky_db(30,3,"Mirca");
    zatoky_db(31,3,"Supetar");
    zatoky_db(32,3,"Babin Laz");
    zatoky_db(33,3,"Splitska");
    zatoky_db(34,3,"Postira");
    zatoky_db(35,3,"Lovrečina");
    zatoky_db(36,3,"Pučišča");
    zatoky_db(37,3,"Bol");
    zatoky_db(38,3,"Blača");
    zatoky_db(39,3,"Krušica");
    zatoky_db(40,3,"Smrka");
    zatoky_db(41,3,"Lučice");
    zatoky_db(42,3,"Osibova");
    zatoky_db(43,3,"Luka");
    zatoky_db(44,3,"Povlja");
    zatoky_db(45,3,"Rasotica");
    zatoky_db(46,3,"Sumartin");
    zatoky_db(47,3,"Studena");
    zatoky_db(48,4,"Pelegrin");
    zatoky_db(49,4,"Parja");
    zatoky_db(50,4,"Duga");
    zatoky_db(51,4,"Vira");
    zatoky_db(52,4,"Pribinja");
    zatoky_db(53,4,"Jagodna");
    zatoky_db(54,4,"Lozna");
    zatoky_db(55,4,"Sviračina");
    zatoky_db(56,4,"Stiniva");
    zatoky_db(57,4,"Lučišče");
    zatoky_db(58,4,"Gračišče");
    zatoky_db(59,4,"Sv. Ante");
    zatoky_db(60,4,"Maslinica");
    zatoky_db(61,4,"Stari Grad");
    zatoky_db(62,4,"Zavala");
    zatoky_db(63,4,"Žukova");
    zatoky_db(64,4,"Dugi Rat");
    zatoky_db(65,4,"Zala luka");
    zatoky_db(66,4,"Vrboska");
    zatoky_db(67,4,"Jelsa");
    zatoky_db(68,4,"Prapratna");
    zatoky_db(69,4,"Mala Stiniva");
    zatoky_db(70,4,"Vela Stiniva");
    zatoky_db(71,4,"Dubac");
    zatoky_db(72,4,"Kruševa");
    zatoky_db(73,4,"Pokrivvenik");
    zatoky_db(74,4,"Bristova");
    zatoky_db(75,4,"Moševica");
    zatoky_db(76,4,"Vela Divlja");
    zatoky_db(77,4,"Vlaska");
    zatoky_db(78,4,"Sučuraj");
    zatoky_db(79,4,"Židigova");
    zatoky_db(80,4,"Rasovatica");
    zatoky_db(81,4,"Prapratna");
    zatoky_db(82,4,"Mrtinovik");
    zatoky_db(83,4,"Aržišče");
    zatoky_db(84,4,"Leprinova");
    zatoky_db(85,4,"Zaglav");
    zatoky_db(86,4,"Smokvina");
    zatoky_db(87,4,"Pelinovik");
    zatoky_db(88,4,"Smarska");
    zatoky_db(89,4,"Torac");
    zatoky_db(90,4,"Skozanje");
    zatoky_db(91,4,"Srhov Dolac");
    zatoky_db(92,4,"Medvidina");
    zatoky_db(93,4,"Crvanj");
    zatoky_db(94,4,"Prisinjak");
    zatoky_db(95,4,"Groman Dolac");
    zatoky_db(96,4,"Zavala");
    zatoky_db(97,4,"Ivan Dolac");
    zatoky_db(98,4,"Sv. Nedjelja");
    zatoky_db(99,4,"Piščena");
    zatoky_db(100,4,"Dubovica");
    zatoky_db(101,4,"Zarače");
    zatoky_db(102,4,"Milna");
    zatoky_db(103,4,"Hvar");
    zatoky_db(104,4,"Podsstine");
    zatoky_db(105,4,"Mala Garška");
    zatoky_db(106,4,"Vela Garška");
    zatoky_db(107,5,"Vela Luka");
    zatoky_db(108,5,"Plitvine");
    zatoky_db(109,5,"Gradina");
    zatoky_db(110,5,"Bristva");
    zatoky_db(111,5,"Prigradica");
    zatoky_db(112,5,"Rasoha");
    zatoky_db(113,5,"Babina");
    zatoky_db(114,5,"Račišče");
    zatoky_db(115,5,"Kneža");
    zatoky_db(116,5,"Vrbovica");
    zatoky_db(117,5,"Banja");
    zatoky_db(118,5,"Korčula");
    zatoky_db(119,5,"Lumbarda");
    zatoky_db(120,5,"Pržina");
    zatoky_db(121,5,"Rasohatica");
    zatoky_db(122,5,"Pavja");
    zatoky_db(123,5,"Orlanduša");
    zatoky_db(124,5,"Bačvica");
    zatoky_db(125,5,"Pupnatska luka");
    zatoky_db(126,5,"Žitna");
    zatoky_db(127,5,"Zavalatica");
    zatoky_db(128,5,"Stiniva");
    zatoky_db(129,5,"Grahova");
    zatoky_db(130,5,"Vlaška");
    zatoky_db(131,5,"Brendana");
    zatoky_db(132,5,"Brna");
    zatoky_db(133,5,"Prižba");
    zatoky_db(134,5,"Grščica");
    zatoky_db(135,5,"Karbuni");
    zatoky_db(136,5,"Zaglav");
    zatoky_db(137,5,"Tri luke");
    zatoky_db(138,5,"Zaklopatica");
    zatoky_db(139,5,"Krnji rat");
    zatoky_db(140,5,"Poplat");
    zatoky_db(141,6,"Ubli");
    zatoky_db(142,6,"Kručica");
    zatoky_db(143,6,"Korita");
    zatoky_db(144,6,"Zaklopanica");
    zatoky_db(145,6,"Lučica");
    zatoky_db(146,6,"Skrivena luka");
    zatoky_db(147,6,"Uska");
    zatoky_db(148,7,"Lokva");
    zatoky_db(149,7,"Pomena");
    zatoky_db(150,7,"Polače");
    zatoky_db(151,7,"Tatinica");
    zatoky_db(152,7,"Kozarica");
    zatoky_db(153,7,"Sobra");
    zatoky_db(154,7,"Okuklje");
    zatoky_db(155,7,"Podškolj");
    zatoky_db(156,7,"Saplunara");
    zatoky_db(157,8,"Lovište");
    zatoky_db(158,8,"Mirce");
    zatoky_db(159,8,"Česminova");
    zatoky_db(160,8,"Križica");
    zatoky_db(161,8,"Dubac");
    zatoky_db(162,8,"Trpanj");
    zatoky_db(163,8,"Crkvice");
    zatoky_db(164,8,"Osobljava");
    zatoky_db(165,8,"Sreser");
    zatoky_db(166,8,"Drače");
    zatoky_db(167,8,"Luka");
    zatoky_db(168,8,"Blaževo");
    zatoky_db(169,8,"Brijesta");
    zatoky_db(170,8,"Hodilje");
    zatoky_db(171,8,"Mali Ston");
    zatoky_db(172,8,"Ston");
    zatoky_db(173,8,"Broce");
    zatoky_db(174,8,"Kobaš");
    zatoky_db(175,8,"Pržina");
    zatoky_db(176,8,"Prapratno");
    zatoky_db(177,8,"Kupinova");
    zatoky_db(178,8,"Žuljana");
    zatoky_db(179,8,"Trstenik");
    zatoky_db(180,8,"Borak");
    zatoky_db(181,8,"Potočine");
    zatoky_db(182,8,"Podobuče");
    zatoky_db(183,8,"Lučica");
    zatoky_db(184,8,"Mokalo");
    zatoky_db(185,8,"Orebič");
    zatoky_db(186,8,"Perna");
    zatoky_db(187,8,"Kučišče");
    zatoky_db(188,8,"Viganj");
    zatoky_db(189,8,"Duba");
    zatoky_db(190,9,"Trogir");
    zatoky_db(191,9,"Split");
    zatoky_db(192,9,"Strožanac");
    zatoky_db(193,9,"Dugi Rat");
    zatoky_db(194,9,"Omiš");
    zatoky_db(195,9,"Baška voda");
    zatoky_db(196,9,"Makarska");
    zatoky_db(197,9,"Tučepi");
    zatoky_db(198,9,"Drvenik");
    zatoky_db(199,9,"Gradac");
    zatoky_db(200,9,"Ploče");
    zatoky_db(201,9,"Dubrovnik");


    QString prikaz_3 = "CREATE TABLE kotveni (id_zatoka integer, molo VARCHAR(20), boje VARCHAR(20), kotva VARCHAR(20) )";

    QSqlQuery query_3;


    if(!query_3.exec(prikaz_3))
    {
        qDebug()<<"Smaž předchozí databázi";
    }

    qDebug()<<"Příprava hodnot pro kotvení provedena.";

    kotveni_db(1,"Ano","Ano","Ano");
    kotveni_db(2,"Ne","Ne","Ano");
    kotveni_db(3,"Ne","Ne","Ano");
    kotveni_db(4,"Ne","Ne","Ano");
    kotveni_db(5,"Ano","Ano","Ne");
    kotveni_db(6,"Ne","Ne","Ano");
    kotveni_db(7,"Ne","Ne","Ano");
    kotveni_db(8,"Ne","Ne","Ano");
    kotveni_db(9,"Ano","Ne","Ano");
    kotveni_db(10,"Ne","Ne","Ano");
    kotveni_db(11,"Ne","Ne","Ano");
    kotveni_db(12,"Ano","Ne","Ne");
    kotveni_db(13,"Ano","Ne","Ne");
    kotveni_db(14,"Ano","Ne","Ne");
    kotveni_db(15,"Ano","Ne","Ano");
    kotveni_db(16,"Ano","Ne","Ne");
    kotveni_db(17,"Ne","Ne","Ano");
    kotveni_db(18,"Ne","Ne","Ano");
    kotveni_db(19,"Ne","Ne","Ano");
    kotveni_db(20,"Ne","Ne","Ano");
    kotveni_db(21,"Ne","Ne","Ano");
    kotveni_db(22,"Ne","Ne","Ano");
    kotveni_db(23,"Ne","Ne","Ano");
    kotveni_db(24,"Ne","Ne","Ano");
    kotveni_db(25,"Ano","Ne","Ne");
    kotveni_db(26,"Ano","Ne","Ano");
    kotveni_db(27,"Ne","Ne","Ano");
    kotveni_db(28,"Ne","Ne","Ano");
    kotveni_db(29,"Ano","Ne","Ne");
    kotveni_db(30,"Ano","Ne","Ne");
    kotveni_db(31,"Ano","Ne","Ne");
    kotveni_db(32,"Ne","Ne","Ano");
    kotveni_db(33,"Ano","Ne","Ne");
    kotveni_db(34,"Ano","Ne","Ne");
    kotveni_db(35,"Ne","Ne","Ano");
    kotveni_db(36,"Ano","Ne","Ne");
    kotveni_db(37,"Ano","Ne","Ano");
    kotveni_db(38,"Ne","Ne","Ano");
    kotveni_db(39,"Ne","Ne","Ano");
    kotveni_db(40,"Ne","Ne","Ano");
    kotveni_db(41,"Ne","Ano","Ano");
    kotveni_db(42,"Ne","Ne","Ano");
    kotveni_db(43,"Ne","Ano","Ano");
    kotveni_db(44,"Ano","Ne","Ano");
    kotveni_db(45,"Ne","Ne","Ano");
    kotveni_db(46,"Ano","Ne","Ne");
    kotveni_db(47,"Ne","Ne","Ano");
    kotveni_db(48,"Ne","Ne","Ano");
    kotveni_db(49,"Ne","Ne","Ano");
    kotveni_db(50,"Ne","Ne","Ano");
    kotveni_db(51,"Ano","Ano","Ano");
    kotveni_db(52,"Ne","Ne","Ano");
    kotveni_db(53,"Ne","Ano","Ano");
    kotveni_db(54,"Ne","Ne","Ano");
    kotveni_db(55,"Ne","Ne","Ano");
    kotveni_db(56,"Ne","Ne","Ano");
    kotveni_db(57,"Ne","Ne","Ano");
    kotveni_db(58,"Ne","Ne","Ano");
    kotveni_db(59,"Ne","Ne","Ano");
    kotveni_db(60,"Ne","Ne","Ano");
    kotveni_db(61,"Ano","Ano","Ano");
    kotveni_db(62,"Ne","Ano","Ne");
    kotveni_db(63,"Ne","Ne","Ano");
    kotveni_db(64,"Ne","Ne","Ano");
    kotveni_db(65,"Ne","Ne","Ano");
    kotveni_db(66,"Ano","Ano","Ano");
    kotveni_db(67,"Ano","Ne","Ano");
    kotveni_db(68,"Ne","Ne","Ano");
    kotveni_db(69,"Ne","Ne","Ano");
    kotveni_db(70,"Ne","Ne","Ano");
    kotveni_db(71,"Ne","Ne","Ne");
    kotveni_db(72,"Ne","Ne","Ano");
    kotveni_db(73,"Ano","Ne","Ano");
    kotveni_db(74,"Ne","Ne","Ano");
    kotveni_db(75,"Ne","Ne","Ano");
    kotveni_db(76,"Ne","Ne","Ano");
    kotveni_db(77,"Ne","Ne","Ano");
    kotveni_db(78,"Ano","Ne","Ne");
    kotveni_db(79,"Ne","Ne","Ano");
    kotveni_db(80,"Ne","Ne","Ano");
    kotveni_db(81,"Ne","Ne","Ano");
    kotveni_db(82,"Ne","Ano","Ne");
    kotveni_db(83,"Ne","Ne","Ano");
    kotveni_db(84,"Ne","Ne","Ano");
    kotveni_db(85,"Ne","Ne","Ano");
    kotveni_db(86,"Ne","Ne","Ano");
    kotveni_db(87,"Ne","Ne","Ano");
    kotveni_db(88,"Ne","Ne","Ano");
    kotveni_db(89,"Ne","Ne","Ano");
    kotveni_db(90,"Ne","Ne","Ano");
    kotveni_db(91,"Ne","Ne","Ano");
    kotveni_db(92,"Ne","Ne","Ano");
    kotveni_db(93,"Ne","Ne","Ano");
    kotveni_db(94,"Ne","Ne","Ne");
    kotveni_db(95,"Ne","Ne","Ne");
    kotveni_db(96,"Ano","Ne","Ano");
    kotveni_db(97,"Ne","Ne","Ano");
    kotveni_db(98,"Ano","Ne","Ne");
    kotveni_db(99,"Ne","Ne","Ano");
    kotveni_db(100,"Ne","Ne","Ano");
    kotveni_db(101,"Ne","Ano","Ano");
    kotveni_db(102,"Ne","Ano","Ano");
    kotveni_db(103,"Ano","Ano","Ne");
    kotveni_db(104,"Ano","Ne","Ne");
    kotveni_db(105,"Ne","Ne","Ne");
    kotveni_db(106,"Ne","Ne","Ano");
    kotveni_db(107,"Ano","Ano","Ano");
    kotveni_db(108,"Ne","Ne","Ano");
    kotveni_db(109,"Ne","Ano","Ano");
    kotveni_db(110,"Ne","Ne","Ne");
    kotveni_db(111,"Ano","Ne","Ne");
    kotveni_db(112,"Ne","Ne","Ano");
    kotveni_db(113,"Ne","Ne","Ano");
    kotveni_db(114,"Ano","Ne","Ano");
    kotveni_db(115,"Ne","Ne","Ano");
    kotveni_db(116,"Ne","Ne","Ano");
    kotveni_db(117,"Ano","Ne","Ano");
    kotveni_db(118,"Ano","Ne","Ne");
    kotveni_db(119,"Ne","Ne","Ano");
    kotveni_db(120,"Ne","Ne","Ano");
    kotveni_db(121,"Ne","Ne","Ano");
    kotveni_db(122,"Ne","Ne","Ano");
    kotveni_db(123,"Ne","Ne","Ano");
    kotveni_db(124,"Ne","Ne","Ano");
    kotveni_db(125,"Ne","Ne","Ano");
    kotveni_db(126,"Ne","Ne","Ano");
    kotveni_db(127,"Ano","Ne","Ne");
    kotveni_db(128,"Ne","Ne","Ano");
    kotveni_db(129,"Ne","Ne","Ano");
    kotveni_db(130,"Ne","Ne","Ano");
    kotveni_db(131,"Ne","Ne","Ano");
    kotveni_db(132,"Ano","Ne","Ano");
    kotveni_db(133,"Ano","Ne","Ano");
    kotveni_db(134,"Ano","Ne","Ne");
    kotveni_db(135,"Ne","Ne","Ne");
    kotveni_db(136,"Ne","Ne","Ne");
    kotveni_db(137,"Ne","Ne","Ano");
    kotveni_db(138,"Ne","Ne","Ano");
    kotveni_db(139,"Ne","Ne","Ne");
    kotveni_db(140,"Ne","Ne","Ano");
    kotveni_db(141,"Ano","Ne","Ne");
    kotveni_db(142,"Ne","Ne","Ano");
    kotveni_db(143,"Ne","Ne","Ano");
    kotveni_db(144,"Ano","Ne","Ne");
    kotveni_db(145,"Ne","Ne","Ano");
    kotveni_db(146,"Ne","Ne","Ano");
    kotveni_db(147,"Ne","Ne","Ano");
    kotveni_db(148,"Ne","Ne","Ano");
    kotveni_db(149,"Ano","Ne","Ano");
    kotveni_db(150,"Ano","Ano","Ano");
    kotveni_db(151,"Ano","Ano","Ne");
    kotveni_db(152,"Ano","Ne","Ne");
    kotveni_db(153,"Ano","Ano","Ano");
    kotveni_db(154,"Ano","Ne","Ne");
    kotveni_db(155,"Ano","Ne","Ne");
    kotveni_db(156,"Ne","Ne","Ano");
    kotveni_db(157,"Ano","Ne","Ne");
    kotveni_db(158,"Ne","Ne","Ano");
    kotveni_db(159,"Ne","Ne","Ano");
    kotveni_db(160,"Ne","Ne","Ano");
    kotveni_db(161,"Ano","Ne","Ne");
    kotveni_db(162,"Ano","Ne","Ne");
    kotveni_db(163,"Ne","Ne","Ne");
    kotveni_db(164,"Ano","Ne","Ne");
    kotveni_db(165,"Ano","Ne","Ne");
    kotveni_db(166,"Ano","Ne","Ne");
    kotveni_db(167,"Ne","Ne","Ano");
    kotveni_db(168,"Ne","Ne","Ne");
    kotveni_db(169,"Ano","Ne","Ano");
    kotveni_db(170,"Ano","Ne","Ne");
    kotveni_db(171,"Ano","Ne","Ano");
    kotveni_db(172,"Ano","Ne","Ano");
    kotveni_db(173,"Ne","Ne","Ne");
    kotveni_db(174,"Ano","Ne","Ne");
    kotveni_db(175,"Ne","Ne","Ano");
    kotveni_db(176,"Ne","Ne","Ano");
    kotveni_db(177,"Ne","Ne","Ano");
    kotveni_db(178,"Ano","Ne","Ano");
    kotveni_db(179,"Ano","Ne","Ano");
    kotveni_db(180,"Ne","Ne","Ne");
    kotveni_db(181,"Ne","Ne","Ne");
    kotveni_db(182,"Ano","Ne","Ne");
    kotveni_db(183,"Ne","Ne","Ne");
    kotveni_db(184,"Ne","Ne","Ne");
    kotveni_db(185,"Ano","Ne","Ne");
    kotveni_db(186,"Ne","Ne","Ne");
    kotveni_db(187,"Ano","Ne","Ne");
    kotveni_db(188,"Ano","Ne","Ano");
    kotveni_db(189,"Ne","Ano","Ne");
    kotveni_db(190,"Ano","Ne","Ano");
    kotveni_db(191,"Ano","Ano","Ano");
    kotveni_db(192,"Ano","Ne","Ne");
    kotveni_db(193,"Ano","Ne","Ne");
    kotveni_db(194,"Ano","Ne","Ne");
    kotveni_db(195,"Ano","Ne","Ne");
    kotveni_db(196,"Ano","Ano","Ne");
    kotveni_db(197,"Ano","Ne","Ne");
    kotveni_db(198,"Ano","Ne","Ne");
    kotveni_db(199,"Ano","Ne","Ano");
    kotveni_db(200,"Ano","Ne","Ne");
    kotveni_db(201,"Ano","Ne","Ne");


    QString prikaz_4 = "CREATE TABLE sluzby (id_zatoka integer, obchod VARCHAR(20), restaurace VARCHAR(20) )";

    QSqlQuery query_4;

    if(!query_4.exec(prikaz_4))
    {
        qDebug()<<"Smaž předchozí databázi";
    }


    qDebug()<<"Příprava hodnot pro služby provedena.";

    sluzby_db(1,"Ano","Ano");
    sluzby_db(2,"Ne","Ne");
    sluzby_db(3,"Ne","Ne");
    sluzby_db(4,"Ne","Ne");
    sluzby_db(5,"Ano","Ano");
    sluzby_db(6,"Ne","Ano");
    sluzby_db(7,"Ne","Ne");
    sluzby_db(8,"Ne","Ne");
    sluzby_db(9,"Ne","Ano");
    sluzby_db(10,"Ne","Ne");
    sluzby_db(11,"Ne","Ano");
    sluzby_db(12,"Ano","Ano");
    sluzby_db(13,"Ne","Ano");
    sluzby_db(14,"Ne","Ano");
    sluzby_db(15,"Ne","Ne");
    sluzby_db(16,"Ano","Ano");
    sluzby_db(17,"Ne","Ne");
    sluzby_db(18,"Ne","Ne");
    sluzby_db(19,"Ne","Ne");
    sluzby_db(20,"Ne","Ano");
    sluzby_db(21,"Ne","Ne");
    sluzby_db(22,"Ne","Ne");
    sluzby_db(23,"Ne","Ne");
    sluzby_db(24,"Ne","Ano");
    sluzby_db(25,"Ano","Ano");
    sluzby_db(26,"Ano","Ne");
    sluzby_db(27,"Ne","Ne");
    sluzby_db(28,"Ne","Ne");
    sluzby_db(29,"Ne","Ne");
    sluzby_db(30,"Ne","Ano");
    sluzby_db(31,"Ano","Ano");
    sluzby_db(32,"Ne","Ne");
    sluzby_db(33,"Ano","Ano");
    sluzby_db(34,"Ano","Ano");
    sluzby_db(35,"Ne","Ano");
    sluzby_db(36,"Ne","Ano");
    sluzby_db(37,"Ano","Ano");
    sluzby_db(38,"Ne","Ne");
    sluzby_db(39,"Ne","Ne");
    sluzby_db(40,"Ne","Ne");
    sluzby_db(41,"Ne","Ano");
    sluzby_db(42,"Ne","Ne");
    sluzby_db(43,"Ne","Ano");
    sluzby_db(44,"Ano","Ano");
    sluzby_db(45,"Ne","Ne");
    sluzby_db(46,"Ano","Ano");
    sluzby_db(47,"Ne","Ne");
    sluzby_db(48,"Ne","Ne");
    sluzby_db(49,"Ne","Ne");
    sluzby_db(50,"Ne","Ne");
    sluzby_db(51,"Ano","Ano");
    sluzby_db(52,"Ne","Ano");
    sluzby_db(53,"Ne","Ne");
    sluzby_db(54,"Ne","Ne");
    sluzby_db(55,"Ne","Ne");
    sluzby_db(56,"Ne","Ne");
    sluzby_db(57,"Ne","Ne");
    sluzby_db(58,"Ne","Ne");
    sluzby_db(59,"Ne","Ne");
    sluzby_db(60,"Ne","Ne");
    sluzby_db(61,"Ano","Ano");
    sluzby_db(62,"Ne","Ano");
    sluzby_db(63,"Ne","Ne");
    sluzby_db(64,"Ne","Ne");
    sluzby_db(65,"Ne","Ne");
    sluzby_db(66,"Ano","Ano");
    sluzby_db(67,"Ano","Ano");
    sluzby_db(68,"Ne","Ano");
    sluzby_db(69,"Ne","Ne");
    sluzby_db(70,"Ne","Ano");
    sluzby_db(71,"Ne","Ne");
    sluzby_db(72,"Ne","Ne");
    sluzby_db(73,"Ne","Ano");
    sluzby_db(74,"Ne","Ne");
    sluzby_db(75,"Ne","Ne");
    sluzby_db(76,"Ne","Ne");
    sluzby_db(77,"Ano","Ano");
    sluzby_db(78,"Ano","Ano");
    sluzby_db(79,"Ne","Ne");
    sluzby_db(80,"Ne","Ne");
    sluzby_db(81,"Ne","Ne");
    sluzby_db(82,"Ne","Ano");
    sluzby_db(83,"Ne","Ne");
    sluzby_db(84,"Ne","Ne");
    sluzby_db(85,"Ne","Ne");
    sluzby_db(86,"Ne","Ne");
    sluzby_db(87,"Ne","Ne");
    sluzby_db(88,"Ne","Ne");
    sluzby_db(89,"Ne","Ne");
    sluzby_db(90,"Ne","Ne");
    sluzby_db(91,"Ne","Ne");
    sluzby_db(92,"Ne","Ne");
    sluzby_db(93,"Ne","Ne");
    sluzby_db(94,"Ne","Ne");
    sluzby_db(95,"Ano","Ano");
    sluzby_db(96,"Ano","Ano");
    sluzby_db(97,"Ne","Ano");
    sluzby_db(98,"Ne","Ano");
    sluzby_db(99,"Ne","Ano");
    sluzby_db(100,"Ne","Ne");
    sluzby_db(101,"Ne","Ano");
    sluzby_db(102,"Ne","Ano");
    sluzby_db(103,"Ne","Ano");
    sluzby_db(104,"Ne","Ano");
    sluzby_db(105,"Ne","Ne");
    sluzby_db(106,"Ne","Ne");
    sluzby_db(107,"Ne","Ano");
    sluzby_db(108,"Ne","Ne");
    sluzby_db(109,"Ano","Ano");
    sluzby_db(110,"Ne","Ne");
    sluzby_db(111,"Ne","Ano");
    sluzby_db(112,"Ne","Ne");
    sluzby_db(113,"Ano","Ano");
    sluzby_db(114,"Ano","Ano");
    sluzby_db(115,"Ano","Ano");
    sluzby_db(116,"Ne","Ne");
    sluzby_db(117,"Ano","Ano");
    sluzby_db(118,"Ano","Ano");
    sluzby_db(119,"Ne","Ano");
    sluzby_db(120,"Ano","Ano");
    sluzby_db(121,"Ne","Ne");
    sluzby_db(122,"Ne","Ne");
    sluzby_db(123,"Ne","Ne");
    sluzby_db(124,"Ne","Ne");
    sluzby_db(125,"Ne","Ano");
    sluzby_db(126,"Ne","Ne");
    sluzby_db(127,"Ano","Ano");
    sluzby_db(128,"Ne","Ne");
    sluzby_db(129,"Ne","Ne");
    sluzby_db(130,"Ne","Ne");
    sluzby_db(131,"Ne","Ne");
    sluzby_db(132,"Ano","Ano");
    sluzby_db(133,"Ano","Ano");
    sluzby_db(134,"Ano","Ano");
    sluzby_db(135,"Ne","Ne");
    sluzby_db(136,"Ne","Ne");
    sluzby_db(137,"Ne","Ano");
    sluzby_db(138,"Ne","Ne");
    sluzby_db(139,"Ne","Ne");
    sluzby_db(140,"Ne","Ne");
    sluzby_db(141,"Ano","Ano");
    sluzby_db(142,"Ne","Ne");
    sluzby_db(143,"Ne","Ne");
    sluzby_db(144,"Ne","Ano");
    sluzby_db(145,"Ne","Ne");
    sluzby_db(146,"Ne","Ano");
    sluzby_db(147,"Ne","Ne");
    sluzby_db(148,"Ano","Ano");
    sluzby_db(149,"Ano","Ano");
    sluzby_db(150,"Ano","Ano");
    sluzby_db(151,"Ano","Ano");
    sluzby_db(152,"Ne","Ano");
    sluzby_db(153,"Ne","Ne");
    sluzby_db(154,"Ano","Ano");
    sluzby_db(155,"Ne","Ne");
    sluzby_db(156,"Ne","Ne");
    sluzby_db(157,"Ano","Ano");
    sluzby_db(158,"Ne","Ne");
    sluzby_db(159,"Ne","Ne");
    sluzby_db(160,"Ne","Ne");
    sluzby_db(161,"Ano","Ano");
    sluzby_db(162,"Ano","Ano");
    sluzby_db(163,"Ne","Ne");
    sluzby_db(164,"Ne","Ne");
    sluzby_db(165,"Ne","Ne");
    sluzby_db(166,"Ne","Ano");
    sluzby_db(167,"Ne","Ne");
    sluzby_db(168,"Ne","Ne");
    sluzby_db(169,"Ne","Ne");
    sluzby_db(170,"Ano","Ne");
    sluzby_db(171,"Ano","Ano");
    sluzby_db(172,"Ano","Ano");
    sluzby_db(173,"Ne","Ne");
    sluzby_db(174,"Ano","Ano");
    sluzby_db(175,"Ne","Ne");
    sluzby_db(176,"Ne","Ne");
    sluzby_db(177,"Ne","Ne");
    sluzby_db(178,"Ano","Ano");
    sluzby_db(179,"Ano","Ano");
    sluzby_db(180,"Ne","Ne");
    sluzby_db(181,"Ne","Ne");
    sluzby_db(182,"Ne","Ne");
    sluzby_db(183,"Ne","Ne");
    sluzby_db(184,"Ne","Ne");
    sluzby_db(185,"Ano","Ano");
    sluzby_db(186,"Ne","Ne");
    sluzby_db(187,"Ne","Ne");
    sluzby_db(188,"Ano","Ne");
    sluzby_db(189,"Ne","Ano");
    sluzby_db(190,"Ano","Ano");
    sluzby_db(191,"Ano","Ano");
    sluzby_db(192,"Ano","Ano");
    sluzby_db(193,"Ano","Ano");
    sluzby_db(194,"Ano","Ano");
    sluzby_db(195,"Ano","Ano");
    sluzby_db(196,"Ano","Ano");
    sluzby_db(197,"Ano","Ano");
    sluzby_db(198,"Ano","Ano");
    sluzby_db(199,"Ano","Ano");
    sluzby_db(200,"Ano","Ano");
    sluzby_db(201,"Ano","Ano");


    pristavy.close();

    return a.exec();
}

void ostrovy_db(int id_ostrov, QString nazev_ostrov)
{
    QSqlQuery query_5;

    QString prikaz_5 = "INSERT INTO ostrovy(id_ostrov,nazev_ostrov) VALUES (?,?)";

    query_5.prepare(prikaz_5);
    query_5.addBindValue(id_ostrov);
    query_5.addBindValue(nazev_ostrov);

    if(!query_5.exec())
    {
        qDebug()<<"Data se nepodařilo přidat do databáze.";
    }


}


void zatoky_db (int id_zatoka, int id_ostrov, QString nazev_zatoka)
{
    QSqlQuery query_6;

    QString prikaz_6 = "INSERT INTO zatoky(id_zatoka,id_ostrov,nazev_zatoka) VALUES (?,?,?)";

    query_6.prepare(prikaz_6);
    query_6.addBindValue(id_zatoka);
    query_6.addBindValue(id_ostrov);
    query_6.addBindValue(nazev_zatoka);

    if(!query_6.exec())
    {
        qDebug()<<"Data se nepodařilo přidat do databáze.";
    }


}

void kotveni_db (int id_zatoka, QString molo, QString boje, QString kotva)
{
    QSqlQuery query_7;

    QString prikaz_7 = "INSERT INTO kotveni(id_zatoka,molo,boje,kotva) VALUES (?,?,?,?)";

    query_7.prepare(prikaz_7);
    query_7.addBindValue(id_zatoka);
    query_7.addBindValue(molo);
    query_7.addBindValue(boje);
    query_7.addBindValue(kotva);

    if(!query_7.exec())
    {
        qDebug()<<"Data se nepodařilo přidat do databáze.";
    }



}

void sluzby_db (int id_zatoka, QString obchod, QString restaurace)
{
    QSqlQuery query_8;

    QString prikaz_8 = "INSERT INTO sluzby(id_zatoka,obchod,restaurace) VALUES (?,?,?)";

    query_8.prepare(prikaz_8);
    query_8.addBindValue(id_zatoka);
    query_8.addBindValue(obchod);
    query_8.addBindValue(restaurace);

    if(!query_8.exec())
    {
        qDebug()<<"Data se nepodařilo přidat do databáze.";
    }


}

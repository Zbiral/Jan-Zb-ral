/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.10.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTableView>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QTabWidget *tabWidget;
    QWidget *tab;
    QWidget *verticalLayoutWidget_2;
    QVBoxLayout *verticalLayout_2;
    QLabel *label_3;
    QComboBox *comboBox_3;
    QPushButton *pushButton_3;
    QLabel *label_4;
    QComboBox *comboBox_4;
    QPushButton *pushButton_4;
    QTextBrowser *textBrowser;
    QWidget *tab_2;
    QPushButton *pushButton;
    QLabel *label;
    QLabel *label_2;
    QLineEdit *lineEdit;
    QPushButton *pushButton_12;
    QWidget *tab_3;
    QPushButton *pushButton_7;
    QLineEdit *lineEdit_3;
    QLabel *label_14;
    QLabel *label_16;
    QLabel *label_15;
    QComboBox *comboBox_9;
    QWidget *tab_4;
    QComboBox *comboBox_14;
    QLabel *label_21;
    QLabel *label_17;
    QComboBox *comboBox_10;
    QLabel *label_18;
    QComboBox *comboBox_13;
    QLabel *label_22;
    QLabel *label_20;
    QPushButton *pushButton_8;
    QComboBox *comboBox_11;
    QComboBox *comboBox_12;
    QPushButton *pushButton_9;
    QLabel *label_19;
    QWidget *tab_5;
    QPushButton *pushButton_10;
    QComboBox *comboBox_18;
    QPushButton *pushButton_11;
    QLabel *label_26;
    QComboBox *comboBox_15;
    QComboBox *comboBox_16;
    QLabel *label_24;
    QComboBox *comboBox_17;
    QLabel *label_27;
    QLabel *label_23;
    QLabel *label_25;
    QWidget *tab_6;
    QTableView *tableView;
    QComboBox *comboBox;
    QComboBox *comboBox_2;
    QComboBox *comboBox_5;
    QComboBox *comboBox_6;
    QComboBox *comboBox_7;
    QComboBox *comboBox_8;
    QComboBox *comboBox_19;
    QLabel *label_5;
    QLabel *label_6;
    QLabel *label_7;
    QLabel *label_8;
    QLabel *label_9;
    QLabel *label_10;
    QLabel *label_11;
    QPushButton *pushButton_2;
    QPushButton *pushButton_5;
    QPushButton *pushButton_6;
    QLabel *label_12;
    QComboBox *comboBox_20;
    QLabel *label_13;
    QPushButton *pushButton_13;
    QComboBox *comboBox_21;
    QPushButton *pushButton_14;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(796, 725);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        tabWidget = new QTabWidget(centralwidget);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        tabWidget->setGeometry(QRect(10, 10, 781, 671));
        tab = new QWidget();
        tab->setObjectName(QStringLiteral("tab"));
        verticalLayoutWidget_2 = new QWidget(tab);
        verticalLayoutWidget_2->setObjectName(QStringLiteral("verticalLayoutWidget_2"));
        verticalLayoutWidget_2->setGeometry(QRect(10, 20, 211, 171));
        verticalLayout_2 = new QVBoxLayout(verticalLayoutWidget_2);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        label_3 = new QLabel(verticalLayoutWidget_2);
        label_3->setObjectName(QStringLiteral("label_3"));

        verticalLayout_2->addWidget(label_3);

        comboBox_3 = new QComboBox(verticalLayoutWidget_2);
        comboBox_3->setObjectName(QStringLiteral("comboBox_3"));

        verticalLayout_2->addWidget(comboBox_3);

        pushButton_3 = new QPushButton(verticalLayoutWidget_2);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));

        verticalLayout_2->addWidget(pushButton_3);

        label_4 = new QLabel(verticalLayoutWidget_2);
        label_4->setObjectName(QStringLiteral("label_4"));

        verticalLayout_2->addWidget(label_4);

        comboBox_4 = new QComboBox(verticalLayoutWidget_2);
        comboBox_4->setObjectName(QStringLiteral("comboBox_4"));

        verticalLayout_2->addWidget(comboBox_4);

        pushButton_4 = new QPushButton(verticalLayoutWidget_2);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));

        verticalLayout_2->addWidget(pushButton_4);

        textBrowser = new QTextBrowser(tab);
        textBrowser->setObjectName(QStringLiteral("textBrowser"));
        textBrowser->setGeometry(QRect(10, 210, 291, 301));
        tabWidget->addTab(tab, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QStringLiteral("tab_2"));
        pushButton = new QPushButton(tab_2);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(60, 100, 161, 31));
        label = new QLabel(tab_2);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(50, 40, 121, 21));
        label_2 = new QLabel(tab_2);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(40, 70, 61, 16));
        lineEdit = new QLineEdit(tab_2);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));
        lineEdit->setGeometry(QRect(90, 70, 151, 21));
        pushButton_12 = new QPushButton(tab_2);
        pushButton_12->setObjectName(QStringLiteral("pushButton_12"));
        pushButton_12->setGeometry(QRect(230, 180, 261, 61));
        tabWidget->addTab(tab_2, QString());
        tab_3 = new QWidget();
        tab_3->setObjectName(QStringLiteral("tab_3"));
        pushButton_7 = new QPushButton(tab_3);
        pushButton_7->setObjectName(QStringLiteral("pushButton_7"));
        pushButton_7->setGeometry(QRect(80, 150, 161, 31));
        lineEdit_3 = new QLineEdit(tab_3);
        lineEdit_3->setObjectName(QStringLiteral("lineEdit_3"));
        lineEdit_3->setGeometry(QRect(110, 110, 151, 21));
        label_14 = new QLabel(tab_3);
        label_14->setObjectName(QStringLiteral("label_14"));
        label_14->setGeometry(QRect(50, 110, 61, 16));
        label_16 = new QLabel(tab_3);
        label_16->setObjectName(QStringLiteral("label_16"));
        label_16->setGeometry(QRect(70, 40, 121, 21));
        label_15 = new QLabel(tab_3);
        label_15->setObjectName(QStringLiteral("label_15"));
        label_15->setGeometry(QRect(50, 70, 61, 16));
        comboBox_9 = new QComboBox(tab_3);
        comboBox_9->setObjectName(QStringLiteral("comboBox_9"));
        comboBox_9->setGeometry(QRect(110, 70, 151, 21));
        tabWidget->addTab(tab_3, QString());
        tab_4 = new QWidget();
        tab_4->setObjectName(QStringLiteral("tab_4"));
        comboBox_14 = new QComboBox(tab_4);
        comboBox_14->setObjectName(QStringLiteral("comboBox_14"));
        comboBox_14->setGeometry(QRect(110, 220, 69, 16));
        label_21 = new QLabel(tab_4);
        label_21->setObjectName(QStringLiteral("label_21"));
        label_21->setGeometry(QRect(30, 20, 161, 21));
        label_17 = new QLabel(tab_4);
        label_17->setObjectName(QStringLiteral("label_17"));
        label_17->setGeometry(QRect(40, 50, 47, 13));
        comboBox_10 = new QComboBox(tab_4);
        comboBox_10->setObjectName(QStringLiteral("comboBox_10"));
        comboBox_10->setGeometry(QRect(110, 200, 69, 16));
        label_18 = new QLabel(tab_4);
        label_18->setObjectName(QStringLiteral("label_18"));
        label_18->setGeometry(QRect(50, 180, 47, 16));
        comboBox_13 = new QComboBox(tab_4);
        comboBox_13->setObjectName(QStringLiteral("comboBox_13"));
        comboBox_13->setGeometry(QRect(110, 180, 69, 16));
        label_22 = new QLabel(tab_4);
        label_22->setObjectName(QStringLiteral("label_22"));
        label_22->setGeometry(QRect(50, 140, 47, 21));
        label_20 = new QLabel(tab_4);
        label_20->setObjectName(QStringLiteral("label_20"));
        label_20->setGeometry(QRect(50, 220, 47, 16));
        pushButton_8 = new QPushButton(tab_4);
        pushButton_8->setObjectName(QStringLiteral("pushButton_8"));
        pushButton_8->setGeometry(QRect(90, 250, 161, 31));
        comboBox_11 = new QComboBox(tab_4);
        comboBox_11->setObjectName(QStringLiteral("comboBox_11"));
        comboBox_11->setGeometry(QRect(100, 140, 151, 21));
        comboBox_12 = new QComboBox(tab_4);
        comboBox_12->setObjectName(QStringLiteral("comboBox_12"));
        comboBox_12->setGeometry(QRect(100, 50, 151, 21));
        pushButton_9 = new QPushButton(tab_4);
        pushButton_9->setObjectName(QStringLiteral("pushButton_9"));
        pushButton_9->setGeometry(QRect(100, 80, 141, 31));
        label_19 = new QLabel(tab_4);
        label_19->setObjectName(QStringLiteral("label_19"));
        label_19->setGeometry(QRect(50, 200, 47, 16));
        tabWidget->addTab(tab_4, QString());
        tab_5 = new QWidget();
        tab_5->setObjectName(QStringLiteral("tab_5"));
        pushButton_10 = new QPushButton(tab_5);
        pushButton_10->setObjectName(QStringLiteral("pushButton_10"));
        pushButton_10->setGeometry(QRect(90, 270, 181, 31));
        comboBox_18 = new QComboBox(tab_5);
        comboBox_18->setObjectName(QStringLiteral("comboBox_18"));
        comboBox_18->setGeometry(QRect(100, 70, 151, 21));
        pushButton_11 = new QPushButton(tab_5);
        pushButton_11->setObjectName(QStringLiteral("pushButton_11"));
        pushButton_11->setGeometry(QRect(100, 100, 141, 31));
        label_26 = new QLabel(tab_5);
        label_26->setObjectName(QStringLiteral("label_26"));
        label_26->setGeometry(QRect(50, 160, 47, 21));
        comboBox_15 = new QComboBox(tab_5);
        comboBox_15->setObjectName(QStringLiteral("comboBox_15"));
        comboBox_15->setGeometry(QRect(120, 220, 69, 16));
        comboBox_16 = new QComboBox(tab_5);
        comboBox_16->setObjectName(QStringLiteral("comboBox_16"));
        comboBox_16->setGeometry(QRect(120, 200, 69, 16));
        label_24 = new QLabel(tab_5);
        label_24->setObjectName(QStringLiteral("label_24"));
        label_24->setGeometry(QRect(40, 70, 47, 13));
        comboBox_17 = new QComboBox(tab_5);
        comboBox_17->setObjectName(QStringLiteral("comboBox_17"));
        comboBox_17->setGeometry(QRect(100, 160, 151, 21));
        label_27 = new QLabel(tab_5);
        label_27->setObjectName(QStringLiteral("label_27"));
        label_27->setGeometry(QRect(50, 220, 61, 16));
        label_23 = new QLabel(tab_5);
        label_23->setObjectName(QStringLiteral("label_23"));
        label_23->setGeometry(QRect(30, 40, 161, 21));
        label_25 = new QLabel(tab_5);
        label_25->setObjectName(QStringLiteral("label_25"));
        label_25->setGeometry(QRect(50, 200, 47, 16));
        tabWidget->addTab(tab_5, QString());
        tab_6 = new QWidget();
        tab_6->setObjectName(QStringLiteral("tab_6"));
        tableView = new QTableView(tab_6);
        tableView->setObjectName(QStringLiteral("tableView"));
        tableView->setGeometry(QRect(10, 0, 761, 241));
        comboBox = new QComboBox(tab_6);
        comboBox->setObjectName(QStringLiteral("comboBox"));
        comboBox->setGeometry(QRect(30, 280, 121, 21));
        comboBox_2 = new QComboBox(tab_6);
        comboBox_2->setObjectName(QStringLiteral("comboBox_2"));
        comboBox_2->setGeometry(QRect(30, 390, 121, 22));
        comboBox_5 = new QComboBox(tab_6);
        comboBox_5->setObjectName(QStringLiteral("comboBox_5"));
        comboBox_5->setGeometry(QRect(310, 280, 69, 22));
        comboBox_6 = new QComboBox(tab_6);
        comboBox_6->setObjectName(QStringLiteral("comboBox_6"));
        comboBox_6->setGeometry(QRect(310, 330, 69, 22));
        comboBox_7 = new QComboBox(tab_6);
        comboBox_7->setObjectName(QStringLiteral("comboBox_7"));
        comboBox_7->setGeometry(QRect(310, 380, 69, 22));
        comboBox_8 = new QComboBox(tab_6);
        comboBox_8->setObjectName(QStringLiteral("comboBox_8"));
        comboBox_8->setGeometry(QRect(500, 280, 69, 22));
        comboBox_19 = new QComboBox(tab_6);
        comboBox_19->setObjectName(QStringLiteral("comboBox_19"));
        comboBox_19->setGeometry(QRect(500, 330, 69, 22));
        label_5 = new QLabel(tab_6);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(30, 260, 91, 16));
        label_6 = new QLabel(tab_6);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(30, 370, 111, 16));
        label_7 = new QLabel(tab_6);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setGeometry(QRect(240, 272, 47, 31));
        label_8 = new QLabel(tab_6);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setGeometry(QRect(240, 330, 47, 21));
        label_9 = new QLabel(tab_6);
        label_9->setObjectName(QStringLiteral("label_9"));
        label_9->setGeometry(QRect(240, 380, 47, 21));
        label_10 = new QLabel(tab_6);
        label_10->setObjectName(QStringLiteral("label_10"));
        label_10->setGeometry(QRect(430, 280, 47, 21));
        label_11 = new QLabel(tab_6);
        label_11->setObjectName(QStringLiteral("label_11"));
        label_11->setGeometry(QRect(430, 322, 61, 31));
        pushButton_2 = new QPushButton(tab_6);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(290, 440, 161, 23));
        pushButton_5 = new QPushButton(tab_6);
        pushButton_5->setObjectName(QStringLiteral("pushButton_5"));
        pushButton_5->setGeometry(QRect(20, 310, 141, 23));
        pushButton_6 = new QPushButton(tab_6);
        pushButton_6->setObjectName(QStringLiteral("pushButton_6"));
        pushButton_6->setGeometry(QRect(600, 260, 161, 41));
        label_12 = new QLabel(tab_6);
        label_12->setObjectName(QStringLiteral("label_12"));
        label_12->setGeometry(QRect(40, 590, 111, 16));
        comboBox_20 = new QComboBox(tab_6);
        comboBox_20->setObjectName(QStringLiteral("comboBox_20"));
        comboBox_20->setGeometry(QRect(40, 500, 121, 21));
        label_13 = new QLabel(tab_6);
        label_13->setObjectName(QStringLiteral("label_13"));
        label_13->setGeometry(QRect(40, 480, 91, 16));
        pushButton_13 = new QPushButton(tab_6);
        pushButton_13->setObjectName(QStringLiteral("pushButton_13"));
        pushButton_13->setGeometry(QRect(30, 530, 141, 23));
        comboBox_21 = new QComboBox(tab_6);
        comboBox_21->setObjectName(QStringLiteral("comboBox_21"));
        comboBox_21->setGeometry(QRect(40, 610, 121, 22));
        pushButton_14 = new QPushButton(tab_6);
        pushButton_14->setObjectName(QStringLiteral("pushButton_14"));
        pushButton_14->setGeometry(QRect(290, 550, 161, 31));
        tabWidget->addTab(tab_6, QString());
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QStringLiteral("menubar"));
        menubar->setGeometry(QRect(0, 0, 796, 21));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        tabWidget->setCurrentIndex(5);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", nullptr));
        label_3->setText(QApplication::translate("MainWindow", "Ostrov", nullptr));
        pushButton_3->setText(QApplication::translate("MainWindow", "Vybrat ostrov", nullptr));
        label_4->setText(QApplication::translate("MainWindow", "Z\303\241toka", nullptr));
        pushButton_4->setText(QApplication::translate("MainWindow", "Zobraz informace", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab), QApplication::translate("MainWindow", "Vyhled\303\241v\303\241n\303\255", nullptr));
        pushButton->setText(QApplication::translate("MainWindow", "P\305\231id\303\241n\303\255 ostrova do datab\303\241ze", nullptr));
        label->setText(QApplication::translate("MainWindow", "P\305\231id\303\241n\303\255 nov\303\251ho ostrova", nullptr));
        label_2->setText(QApplication::translate("MainWindow", "N\303\241zev: ", nullptr));
        pushButton_12->setText(QApplication::translate("MainWindow", "Aktualizace dat v datab\303\241zi", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QApplication::translate("MainWindow", "Vlo\305\276en\303\255 ostrov\305\257", nullptr));
        pushButton_7->setText(QApplication::translate("MainWindow", "P\305\231id\303\241n\303\255 z\303\241toky do datab\303\241ze", nullptr));
        label_14->setText(QApplication::translate("MainWindow", "N\303\241zev: ", nullptr));
        label_16->setText(QApplication::translate("MainWindow", "P\305\231id\303\241n\303\255 nov\303\251 z\303\241toky", nullptr));
        label_15->setText(QApplication::translate("MainWindow", "Ostrov: ", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_3), QApplication::translate("MainWindow", "P\305\231id\303\241n\303\255 z\303\241tok", nullptr));
        label_21->setText(QApplication::translate("MainWindow", "P\305\231id\303\241n\303\255 nov\303\251ho kotven\303\255 v z\303\241toce", nullptr));
        label_17->setText(QApplication::translate("MainWindow", "Ostrov: ", nullptr));
        label_18->setText(QApplication::translate("MainWindow", "Molo: ", nullptr));
        label_22->setText(QApplication::translate("MainWindow", "Z\303\241toka: ", nullptr));
        label_20->setText(QApplication::translate("MainWindow", "Kotva: ", nullptr));
        pushButton_8->setText(QApplication::translate("MainWindow", "P\305\231id\303\241n\303\255 kotveni do datab\303\241ze", nullptr));
        pushButton_9->setText(QApplication::translate("MainWindow", "Vypi\305\241 z\303\241toky pro ostrov", nullptr));
        label_19->setText(QApplication::translate("MainWindow", "B\303\263je: ", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_4), QApplication::translate("MainWindow", "P\305\231id\303\241n\303\255 kotven\303\255", nullptr));
        pushButton_10->setText(QApplication::translate("MainWindow", "P\305\231id\303\241n\303\255 nov\303\275ch slu\305\276eb do datab\303\241ze", nullptr));
        pushButton_11->setText(QApplication::translate("MainWindow", "Vypi\305\241 z\303\241toky pro ostrov", nullptr));
        label_26->setText(QApplication::translate("MainWindow", "Z\303\241toka: ", nullptr));
        label_24->setText(QApplication::translate("MainWindow", "Ostrov: ", nullptr));
        label_27->setText(QApplication::translate("MainWindow", "Restaurace: ", nullptr));
        label_23->setText(QApplication::translate("MainWindow", "P\305\231id\303\241n\303\255 nov\303\275ch slu\305\276eb v z\303\241toce", nullptr));
        label_25->setText(QApplication::translate("MainWindow", "Obchod: ", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_5), QApplication::translate("MainWindow", "P\305\231id\303\241n\303\255 slu\305\276eb", nullptr));
        label_5->setText(QApplication::translate("MainWindow", "V\303\275b\304\233r ostrova", nullptr));
        label_6->setText(QApplication::translate("MainWindow", "V\303\275b\304\233r z\303\241toky", nullptr));
        label_7->setText(QApplication::translate("MainWindow", "Molo: ", nullptr));
        label_8->setText(QApplication::translate("MainWindow", "B\303\263je: ", nullptr));
        label_9->setText(QApplication::translate("MainWindow", "Kotva: ", nullptr));
        label_10->setText(QApplication::translate("MainWindow", "Obchod: ", nullptr));
        label_11->setText(QApplication::translate("MainWindow", "Restaurace: ", nullptr));
        pushButton_2->setText(QApplication::translate("MainWindow", "Aktualizovat", nullptr));
        pushButton_5->setText(QApplication::translate("MainWindow", "Vypi\305\241 z\303\241toky pro ostrov", nullptr));
        pushButton_6->setText(QApplication::translate("MainWindow", "Zobrazit datab\303\241zi", nullptr));
        label_12->setText(QApplication::translate("MainWindow", "V\303\275b\304\233r z\303\241toky", nullptr));
        label_13->setText(QApplication::translate("MainWindow", "V\303\275b\304\233r ostrova", nullptr));
        pushButton_13->setText(QApplication::translate("MainWindow", "Vypi\305\241 z\303\241toky pro ostrov", nullptr));
        pushButton_14->setText(QApplication::translate("MainWindow", "Smazat vybranou z\303\241toku ", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_6), QApplication::translate("MainWindow", "Editace", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H

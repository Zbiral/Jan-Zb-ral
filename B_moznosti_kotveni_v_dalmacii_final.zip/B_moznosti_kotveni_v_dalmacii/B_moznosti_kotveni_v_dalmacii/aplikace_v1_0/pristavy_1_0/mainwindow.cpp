#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QtSql>
#include <QDebug>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlRecord>
#include <QDesktopServices>
#include <QUrl>




MainWindow::~MainWindow()
{
    delete ui;
}



MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    QSqlDatabase data = QSqlDatabase::addDatabase("QSQLITE");
    data.setDatabaseName("../pristavy.db");

    if(data.open())
    {
        qDebug() << "Připojení databáze proběhlo úspěšně" << "\n";
    }
    else
    {
        qDebug() << "Připojení databáze se nezdařilo" << "\n";
    }


    ui->comboBox_3->clear();
    ui->comboBox_3->addItem("Vyber ostrov");
    ui->comboBox_3->addItems(vyber_ostrov());

    ui->comboBox_4->clear();
    ui->comboBox_4->addItem("Potvrď výběr ostrova");

    ui->comboBox_12->clear();
    ui->comboBox_12->addItem("Vyber ostrov");
    ui->comboBox_12->addItems(vyber_ostrov());

    ui->comboBox_11->clear();
    ui->comboBox_11->addItem("Potvrď výběr ostrova");

    QStringList ano_ne;
    QString volba = "Ano,Ne";
    ano_ne = volba.split(",");

    ui->comboBox_13->clear();
    ui->comboBox_13->addItems(ano_ne);

    ui->comboBox_10->clear();
    ui->comboBox_10->addItems(ano_ne);

    ui->comboBox_14->clear();
    ui->comboBox_14->addItems(ano_ne);

    ui->comboBox_18->clear();
    ui->comboBox_18->addItem("Vyber ostrov");
    ui->comboBox_18->addItems(vyber_ostrov());

    ui->comboBox_17->clear();
    ui->comboBox_17->addItem("Potvrď výběr ostrova");

    ui->comboBox_16->clear();
    ui->comboBox_16->addItems(ano_ne);

    ui->comboBox_15->clear();
    ui->comboBox_15->addItems(ano_ne);

    ui->comboBox_9->clear();
    ui->comboBox_9->addItem("Vyber ostrov");
    ui->comboBox_9->addItems(vyber_ostrov());

    ui->comboBox->clear();
    ui->comboBox->addItem("Vyber ostrov");
    ui->comboBox->addItems(vyber_ostrov());

    ui->comboBox_2->clear();
    ui->comboBox_2->addItem("Potvrď výběr ostrova");

    ui->comboBox_5->clear();
    ui->comboBox_5->addItems(ano_ne);

    ui->comboBox_6->clear();
    ui->comboBox_6->addItems(ano_ne);

    ui->comboBox_7->clear();
    ui->comboBox_7->addItems(ano_ne);

    ui->comboBox_8->clear();
    ui->comboBox_8->addItems(ano_ne);

    ui->comboBox_19->clear();
    ui->comboBox_19->addItems(ano_ne);

    ui->comboBox_20->clear();
    ui->comboBox_20->addItem("Vyber ostrov");
    ui->comboBox_20->addItems(vyber_ostrov());

    ui->comboBox_21->clear();
    ui->comboBox_21->addItem("Potvrď výběr ostrova");

}




QStringList MainWindow::vyber_ostrov()
{
    QSqlQuery *vypis_ostrovu = new QSqlQuery;

    QString prikaz="SELECT nazev_ostrov FROM ostrovy";
    vypis_ostrovu->prepare(prikaz);
    vypis_ostrovu->exec(prikaz);

    QStringList seznam_ostrovu;

    while (vypis_ostrovu->next()) {
        QString ostrov=vypis_ostrovu->value(0).toString();
        seznam_ostrovu.append(ostrov);
    }
    return seznam_ostrovu;

}


QStringList MainWindow::vyber_zatoku()
{
    QSqlQuery *vypis_zatok = new QSqlQuery;

    QString zadany_ostrov=ui->comboBox_3->currentText();
    QString prikaz2="SELECT nazev_zatoka from zatoky JOIN ostrovy on ostrovy.id_ostrov = zatoky.id_ostrov where nazev_ostrov = '"+zadany_ostrov+"'";
    vypis_zatok->prepare(prikaz2);
    vypis_zatok->exec();

    QStringList seznam_zatok;

    while (vypis_zatok->next()) {
        QString zatoka=vypis_zatok->value(0).toString();
        seznam_zatok.append(zatoka);
    }
    return seznam_zatok;
}

QStringList MainWindow::vyber_zatoku_2()
{
    QSqlQuery *vypis_zatok = new QSqlQuery;

    QString zadany_ostrov=ui->comboBox_12->currentText();
    QString prikaz2="SELECT nazev_zatoka from zatoky JOIN ostrovy on ostrovy.id_ostrov = zatoky.id_ostrov where nazev_ostrov = '"+zadany_ostrov+"'";
    vypis_zatok->prepare(prikaz2);
    vypis_zatok->exec();

    QStringList seznam_zatok;

    while (vypis_zatok->next()) {
        QString zatoka=vypis_zatok->value(0).toString();
        seznam_zatok.append(zatoka);
    }
    return seznam_zatok;
}


QStringList MainWindow::vyber_zatoku_3()
{
    QSqlQuery *vypis_zatok = new QSqlQuery;

    QString zadany_ostrov=ui->comboBox_18->currentText();
    QString prikaz2="SELECT nazev_zatoka from zatoky JOIN ostrovy on ostrovy.id_ostrov = zatoky.id_ostrov where nazev_ostrov = '"+zadany_ostrov+"'";
    vypis_zatok->prepare(prikaz2);
    vypis_zatok->exec();

    QStringList seznam_zatok;

    while (vypis_zatok->next()) {
        QString zatoka=vypis_zatok->value(0).toString();
        seznam_zatok.append(zatoka);
    }
    return seznam_zatok;
}

QStringList MainWindow::vyber_zatoku_4()
{
    QSqlQuery *vypis_zatok = new QSqlQuery;

    QString zadany_ostrov=ui->comboBox->currentText();
    QString prikaz2="SELECT nazev_zatoka from zatoky JOIN ostrovy on ostrovy.id_ostrov = zatoky.id_ostrov where nazev_ostrov = '"+zadany_ostrov+"'";
    vypis_zatok->prepare(prikaz2);
    vypis_zatok->exec();

    QStringList seznam_zatok;

    while (vypis_zatok->next()) {
        QString zatoka=vypis_zatok->value(0).toString();
        seznam_zatok.append(zatoka);
    }
    return seznam_zatok;
}

QStringList MainWindow::vyber_zatoku_5()
{
    QSqlQuery *vypis_zatok = new QSqlQuery;

    QString zadany_ostrov=ui->comboBox_20->currentText();
    QString prikaz2="SELECT nazev_zatoka from zatoky JOIN ostrovy on ostrovy.id_ostrov = zatoky.id_ostrov where nazev_ostrov = '"+zadany_ostrov+"'";
    vypis_zatok->prepare(prikaz2);
    vypis_zatok->exec();

    QStringList seznam_zatok;

    while (vypis_zatok->next()) {
        QString zatoka=vypis_zatok->value(0).toString();
        seznam_zatok.append(zatoka);
    }
    return seznam_zatok;
}


void MainWindow::on_pushButton_3_clicked()
{
    ui->comboBox_4->clear();
    ui->comboBox_4->addItem("Vyber zátoku");
    ui->comboBox_4->addItems(vyber_zatoku());
}


void MainWindow::on_pushButton_4_clicked()
{         
     QString vybrana_zatoka=ui->comboBox_4->currentText();

     QString prikaz_1="SELECT nazev_zatoka FROM zatoky WHERE nazev_zatoka = '"+vybrana_zatoka+"'";
     QString prikaz_2="SELECT nazev_ostrov FROM ostrovy JOIN zatoky on zatoky.id_ostrov=ostrovy.id_ostrov WHERE nazev_zatoka = '"+vybrana_zatoka+"'";
     QString prikaz_3="SELECT molo FROM kotveni JOIN zatoky on zatoky.id_zatoka=kotveni.id_zatoka WHERE nazev_zatoka = '"+vybrana_zatoka+"'";
     QString prikaz_4="SELECT boje FROM kotveni JOIN zatoky on zatoky.id_zatoka=kotveni.id_zatoka WHERE nazev_zatoka = '"+vybrana_zatoka+"'";
     QString prikaz_5="SELECT kotva FROM kotveni JOIN zatoky on zatoky.id_zatoka=kotveni.id_zatoka WHERE nazev_zatoka = '"+vybrana_zatoka+"'";
     QString prikaz_6="SELECT obchod FROM sluzby JOIN zatoky on zatoky.id_zatoka=sluzby.id_zatoka WHERE nazev_zatoka = '"+vybrana_zatoka+"'";
     QString prikaz_7="SELECT restaurace FROM sluzby JOIN zatoky on zatoky.id_zatoka=sluzby.id_zatoka WHERE nazev_zatoka = '"+vybrana_zatoka+"'";

     QSqlQuery *informace = new QSqlQuery;


     informace->prepare(prikaz_1);
     informace->exec();
     informace->first();
     QString zatoka=informace->value(0).toString();
     informace->prepare(prikaz_2);
     informace->exec();
     informace->first();
     QString ostrov=informace->value(0).toString();
     informace->prepare(prikaz_3);
     informace->exec();
     informace->first();
     QString molo=informace->value(0).toString();
     informace->prepare(prikaz_4);
     informace->exec();
     informace->first();
     QString boje=informace->value(0).toString();
     informace->prepare(prikaz_5);
     informace->exec();
     informace->first();
     QString kotva=informace->value(0).toString();
     informace->prepare(prikaz_6);
     informace->exec();
     informace->first();
     QString obchod=informace->value(0).toString();
     informace->prepare(prikaz_7);
     informace->exec();
     informace->first();
     QString restaurace=informace->value(0).toString();



     QString vypsani ="Zátoka "+zatoka+" se nachází na ostrove "+ostrov+".\n"
                      "\n"
                      "Možnosti kotvení: \n"
                      "Stání u mola : "+molo+"\n"
                      "Stání na bóji : "+boje+"\n"
                      "Kotvení : "+kotva+"\n"
                      "\n"
                      "Dostupnost obchodů/restaurací:\n"
                      "Obchod : "+obchod+"\n"
                      "Restaurace : "+restaurace+"\n";

     ui->textBrowser->clear();
     ui->textBrowser->setText(vypsani);

     ui->comboBox_3->clear();
     ui->comboBox_3->addItem("Vyber ostrov");
     ui->comboBox_3->addItems(vyber_ostrov());

     ui->comboBox_4->clear();
     ui->comboBox_4->addItem("Potvrď výběr ostrova");
}

void MainWindow::on_pushButton_clicked()
{
    QString naz_nov_ostrov=ui->lineEdit->text();

    QSqlQuery *prikaz_ed = new QSqlQuery;

    QString nove_id="SELECT max(id_ostrov)+1 FROM ostrovy";
    prikaz_ed->prepare(nove_id);
    prikaz_ed->exec();
    prikaz_ed->first();
    QString maximalni_id=prikaz_ed->value(0).toString();


    QString zapis_ostrova="INSERT INTO ostrovy VALUES("+maximalni_id+", '"+naz_nov_ostrov+"')";
    prikaz_ed->prepare(zapis_ostrova);
    prikaz_ed->exec();

    ui->lineEdit->clear();

}



void MainWindow::on_pushButton_7_clicked()
{
    QString ostrov_zatoky=ui->comboBox_9->currentText();

    QString naz_nov_zatoky=ui->lineEdit_3->text();

    QSqlQuery *prikaz_ed_2 = new QSqlQuery;

    QString id_ostrov_zatoky="SELECT id_ostrov from ostrovy WHERE nazev_ostrov='"+ostrov_zatoky+"'";
    prikaz_ed_2->prepare(id_ostrov_zatoky);
    prikaz_ed_2->exec();
    prikaz_ed_2->first();
    QString id_ostrov=prikaz_ed_2->value(0).toString();


    QString nove_id="SELECT max(id_zatoka)+1 FROM zatoky";
    prikaz_ed_2->prepare(nove_id);
    prikaz_ed_2->exec();
    prikaz_ed_2->first();
    QString maximalni_id_2=prikaz_ed_2->value(0).toString();


    QString zapis_zatoky="INSERT INTO zatoky VALUES("+maximalni_id_2+","+id_ostrov+",'"+naz_nov_zatoky+"')";
    prikaz_ed_2->prepare(zapis_zatoky);
    prikaz_ed_2->exec();

    ui->lineEdit_3->clear();

    ui->comboBox_9->clear();
    ui->comboBox_9->addItem("Vyber ostrov");
    ui->comboBox_9->addItems(vyber_ostrov());

}

void MainWindow::on_pushButton_9_clicked()
{
    ui->comboBox_11->clear();
    ui->comboBox_11->addItem("Vyber zátoku");
    ui->comboBox_11->addItems(vyber_zatoku_2());
}

void MainWindow::on_pushButton_8_clicked()
{
    QString ostrov_kotveni=ui->comboBox_12->currentText();
    QString zatoka_kotveni=ui->comboBox_11->currentText();
    QString molo_kotveni=ui->comboBox_13->currentText();
    QString boje_kotveni=ui->comboBox_10->currentText();
    QString kotva_kotveni=ui->comboBox_14->currentText();

    QSqlQuery *hled_id_zat = new QSqlQuery;

    QString id_dotaz_kot="SELECT id_zatoka from zatoky WHERE nazev_zatoka='"+zatoka_kotveni+"'";
    hled_id_zat->prepare(id_dotaz_kot);
    hled_id_zat->exec();
    hled_id_zat->first();
    QString id_zatoky=hled_id_zat->value(0).toString();

    QString prikaz_kotveni_ed="INSERT INTO kotveni VALUES("+id_zatoky+",'"+molo_kotveni+"','"+boje_kotveni+"','"+kotva_kotveni+"')";
    hled_id_zat->prepare(prikaz_kotveni_ed);
    hled_id_zat->exec();

    ui->comboBox_12->clear();
    ui->comboBox_12->addItem("Vyber ostrov");
    ui->comboBox_12->addItems(vyber_ostrov());

    ui->comboBox_11->clear();
    ui->comboBox_11->addItem("Potvrď výběr ostrova");

    QStringList ano_ne;
    QString volba = "Ano,Ne";
    ano_ne = volba.split(",");

    ui->comboBox_13->clear();
    ui->comboBox_13->addItems(ano_ne);

    ui->comboBox_10->clear();
    ui->comboBox_10->addItems(ano_ne);

    ui->comboBox_14->clear();
    ui->comboBox_14->addItems(ano_ne);

}

void MainWindow::on_pushButton_11_clicked()
{
    ui->comboBox_17->clear();
    ui->comboBox_17->addItem("Vyber zátoku");
    ui->comboBox_17->addItems(vyber_zatoku_3());


}

void MainWindow::on_pushButton_10_clicked()
{
    QString ostrov_sluzby=ui->comboBox_18->currentText();
    QString zatoka_sluzby=ui->comboBox_17->currentText();
    QString obchod_sluzby=ui->comboBox_16->currentText();
    QString restaurace_sluzby=ui->comboBox_15->currentText();

    QSqlQuery *hled_id_zat_2 = new QSqlQuery;

    QString id_dotaz_sluz="SELECT id_zatoka from zatoky WHERE nazev_zatoka='"+zatoka_sluzby+"'";
    hled_id_zat_2->prepare(id_dotaz_sluz);
    hled_id_zat_2->exec();
    hled_id_zat_2->first();
    QString id_zatoky=hled_id_zat_2->value(0).toString();

    QString prikaz_sluzby_ed="INSERT INTO sluzby VALUES("+id_zatoky+",'"+obchod_sluzby+"','"+restaurace_sluzby+"')";
    hled_id_zat_2->prepare(prikaz_sluzby_ed);
    hled_id_zat_2->exec();

    ui->comboBox_18->clear();
    ui->comboBox_18->addItem("Vyber ostrov");
    ui->comboBox_18->addItems(vyber_ostrov());

    ui->comboBox_17->clear();
    ui->comboBox_17->addItem("Potvrď výběr ostrova");

    QStringList ano_ne;
    QString volba = "Ano,Ne";
    ano_ne = volba.split(",");

    ui->comboBox_16->clear();
    ui->comboBox_16->addItems(ano_ne);

    ui->comboBox_15->clear();
    ui->comboBox_15->addItems(ano_ne);




}



void MainWindow::on_pushButton_5_clicked()
{
    ui->comboBox_2->clear();
    ui->comboBox_2->addItem("Vyber zátoku");
    ui->comboBox_2->addItems(vyber_zatoku_4());
}




void MainWindow::on_pushButton_2_clicked()
{
    QString edit_zatoka=ui->comboBox_2->currentText();
    QString edit_molo=ui->comboBox_5->currentText();
    QString edit_boje=ui->comboBox_6->currentText();
    QString edit_kotva=ui->comboBox_7->currentText();
    QString edit_obchod=ui->comboBox_8->currentText();
    QString edit_restaurace=ui->comboBox_19->currentText();

    QSqlQuery *edit_data = new QSqlQuery;

    QString id_dotaz_edit="SELECT id_zatoka from zatoky WHERE nazev_zatoka='"+edit_zatoka+"'";
    edit_data->prepare(id_dotaz_edit);
    edit_data->exec();
    edit_data->first();
    QString id_zatoky_edit=edit_data->value(0).toString();

    QString prikaz_edit="UPDATE kotveni SET id_zatoka="+id_zatoky_edit+",molo='"+edit_molo+"',boje='"+edit_boje+"',kotva='"+edit_kotva+"' WHERE id_zatoka='"+id_zatoky_edit+"'";
    edit_data->prepare(prikaz_edit);
    edit_data->exec();
    edit_data->first();

    QString prikaz_edit_2="UPDATE sluzby SET id_zatoka="+id_zatoky_edit+",obchod='"+edit_obchod+"',restaurace='"+edit_restaurace+"' WHERE id_zatoka='"+id_zatoky_edit+"'";
    edit_data->prepare(prikaz_edit_2);
    edit_data->exec();
    edit_data->first();

    ui->comboBox->clear();
    ui->comboBox->addItem("Vyber ostrov");
    ui->comboBox->addItems(vyber_ostrov());

    ui->comboBox_2->clear();
    ui->comboBox_2->addItem("Potvrď výběr ostrova");

    QStringList ano_ne;
    QString volba = "Ano,Ne";
    ano_ne = volba.split(",");

    ui->comboBox_5->clear();
    ui->comboBox_5->addItems(ano_ne);

    ui->comboBox_6->clear();
    ui->comboBox_6->addItems(ano_ne);

    ui->comboBox_7->clear();
    ui->comboBox_7->addItems(ano_ne);

    ui->comboBox_8->clear();
    ui->comboBox_8->addItems(ano_ne);

    ui->comboBox_19->clear();
    ui->comboBox_19->addItems(ano_ne);


}




void MainWindow::on_pushButton_6_clicked()
{
    QSqlQueryModel *model1=new QSqlQueryModel();
    QSqlQuery *dotaz_zobr=new QSqlQuery();

    QString dotaz_zobraz="SELECT nazev_zatoka,molo,boje,kotva,obchod,restaurace FROM zatoky JOIN kotveni ON zatoky.id_zatoka=kotveni.id_zatoka JOIN sluzby ON zatoky.id_zatoka=sluzby.id_zatoka";
    dotaz_zobr->prepare(dotaz_zobraz);
    dotaz_zobr->exec();
    dotaz_zobr->first();

    model1 -> setQuery(*dotaz_zobr);
    ui -> tableView -> setModel(model1);


}




void MainWindow::on_pushButton_12_clicked()
{
    ui->comboBox_3->clear();
    ui->comboBox_3->addItem("Vyber ostrov");
    ui->comboBox_3->addItems(vyber_ostrov());

    ui->comboBox_12->clear();
    ui->comboBox_12->addItem("Vyber ostrov");
    ui->comboBox_12->addItems(vyber_ostrov());

    ui->comboBox_18->clear();
    ui->comboBox_18->addItem("Vyber ostrov");
    ui->comboBox_18->addItems(vyber_ostrov());

    ui->comboBox->clear();
    ui->comboBox->addItem("Vyber ostrov");
    ui->comboBox->addItems(vyber_ostrov());

    ui->comboBox_9->clear();
    ui->comboBox_9->addItem("Vyber ostrov");
    ui->comboBox_9->addItems(vyber_ostrov());

    ui->comboBox_20->clear();
    ui->comboBox_20->addItem("Vyber ostrov");
    ui->comboBox_20->addItems(vyber_ostrov());

}

void MainWindow::on_pushButton_13_clicked()
{
    ui->comboBox_21->clear();
    ui->comboBox_21->addItem("Vyber zátoku");
    ui->comboBox_21->addItems(vyber_zatoku_5());
}


void MainWindow::on_pushButton_14_clicked()
{
    QString mazana_zatoka=ui->comboBox_21->currentText();

    QSqlQuery *mazani_data = new QSqlQuery;

    QString id_dotaz_mazani="SELECT id_zatoka from zatoky WHERE nazev_zatoka='"+mazana_zatoka+"'";
    mazani_data->prepare(id_dotaz_mazani);
    mazani_data->exec();
    mazani_data->first();
    QString id_zatoky_mazani=mazani_data->value(0).toString();



    QString mazani_prikaz_1="DELETE FROM zatoky WHERE id_zatoka="+id_zatoky_mazani+"";
    QString mazani_prikaz_2="DELETE FROM kotveni WHERE id_zatoka="+id_zatoky_mazani+"";
    QString mazani_prikaz_3="DELETE FROM sluzby WHERE id_zatoka="+id_zatoky_mazani+"";

    mazani_data->prepare(mazani_prikaz_1);
    mazani_data->exec();
    mazani_data->first();

    mazani_data->prepare(mazani_prikaz_2);
    mazani_data->exec();
    mazani_data->first();

    mazani_data->prepare(mazani_prikaz_3);
    mazani_data->exec();
    mazani_data->first();

    ui->comboBox_20->clear();
    ui->comboBox_20->addItem("Vyber ostrov");
    ui->comboBox_20->addItems(vyber_ostrov());

    ui->comboBox_21->clear();
    ui->comboBox_21->addItem("Potvrď výběr ostrova");


}



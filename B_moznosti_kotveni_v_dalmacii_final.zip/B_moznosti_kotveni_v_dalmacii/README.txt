155PJIN

Skupina B
Možnosti kotvení v Dalmácii

Ve složce "B_moznosti_kotveni_v_dalmacii", podložce "aplikace_v1_0" se nachází složka se soubory pro Qt Creator a databáze.
Ve složce "tvorba_db_kotveni" se nachází projekt pro tvorbu databáze.
Ve složce "B_moznosti_kotveni_v_dalmacii_aplikace" se nachází exe soubour pro spuštění aplikace.

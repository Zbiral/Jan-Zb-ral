#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QtSql>
#include <QDebug>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlRecord>
#include <QDesktopServices>
#include <QUrl>




MainWindow::~MainWindow()
{
    delete ui;
}



MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    QSqlDatabase data = QSqlDatabase::addDatabase("QSQLITE");
    data.setDatabaseName("../pristavy.db");

    if(data.open())
    {
        qDebug() << "Připojení databáze proběhlo úspěšně" << "\n";
    }
    else
    {
        qDebug() << "Připojení databáze se nezdařilo" << "\n";
    }

//nastavení zobrazeni v comboBoxech

    ui->comboBox_3->clear();
    ui->comboBox_3->addItem("Vyber ostrov");
    ui->comboBox_3->addItems(vyber_ostrov());

    ui->comboBox_4->clear();
    ui->comboBox_4->addItem("Potvrď výběr ostrova");
}



//funkce QStringList pro naplnění prvního comboBoxu

QStringList MainWindow::vyber_ostrov()
{
    QSqlQuery *vypis_ostrovu = new QSqlQuery;     //vytvoření nového query (použiji vždy!!)

    QString prikaz="SELECT nazev_ostrov FROM ostrovy";
    vypis_ostrovu->prepare(prikaz);
    vypis_ostrovu->exec(prikaz);

    QStringList seznam_ostrovu;                   //do proměné QStringList ukládám seznam věcí vyhledaných v db

    while (vypis_ostrovu->next()) {
        QString ostrov=vypis_ostrovu->value(0).toString();      //uložení jednotlivých položek do QStringListu
        seznam_ostrovu.append(ostrov);
    }
    return seznam_ostrovu;

}

//funkce QStringList pro vyhledání zátok na zadaném ostrově

QStringList MainWindow::vyber_zatoku()
{
    QSqlQuery *vypis_zatok = new QSqlQuery;

    QString zadany_ostrov=ui->comboBox_3->currentText();        //převzetí hodnoty vybrané v comboBoxu_3
    QString prikaz2="SELECT nazev_zatoka from zatoky JOIN ostrovy on ostrovy.id_ostrov = zatoky.id_ostrov where nazev_ostrov = '"+zadany_ostrov+"'";
    vypis_zatok->prepare(prikaz2);
    vypis_zatok->exec();

    QStringList seznam_zatok;

    while (vypis_zatok->next()) {
        QString zatoka=vypis_zatok->value(0).toString();
        seznam_zatok.append(zatoka);
    }
    return seznam_zatok;
}

//funkce která po kliknutí na pushButton_3 vypíše zátoky na vybraném ostrově

void MainWindow::on_pushButton_3_clicked()
{
    ui->comboBox_4->clear();
    ui->comboBox_4->addItem("Vyber zátoku");
    ui->comboBox_4->addItems(vyber_zatoku());
}

//funkce která po kliknutí na pushButton_4 vypíše do textBrowseru všechna data o vybrané zátoce

void MainWindow::on_pushButton_4_clicked()
{         
     QString vybrana_zatoka=ui->comboBox_4->currentText();

     QString prikaz_1="SELECT nazev_zatoka FROM zatoky WHERE nazev_zatoka = '"+vybrana_zatoka+"'";
     QString prikaz_2="SELECT nazev_ostrov FROM ostrovy JOIN zatoky on zatoky.id_ostrov=ostrovy.id_ostrov WHERE nazev_zatoka = '"+vybrana_zatoka+"'";
     QString prikaz_3="SELECT molo FROM kotveni JOIN zatoky on zatoky.id_zatoka=kotveni.id_zatoka WHERE nazev_zatoka = '"+vybrana_zatoka+"'";
     QString prikaz_4="SELECT boje FROM kotveni JOIN zatoky on zatoky.id_zatoka=kotveni.id_zatoka WHERE nazev_zatoka = '"+vybrana_zatoka+"'";
     QString prikaz_5="SELECT kotva FROM kotveni JOIN zatoky on zatoky.id_zatoka=kotveni.id_zatoka WHERE nazev_zatoka = '"+vybrana_zatoka+"'";
     QString prikaz_6="SELECT obchod FROM sluzby JOIN zatoky on zatoky.id_zatoka=sluzby.id_zatoka WHERE nazev_zatoka = '"+vybrana_zatoka+"'";
     QString prikaz_7="SELECT restaurace FROM sluzby JOIN zatoky on zatoky.id_zatoka=sluzby.id_zatoka WHERE nazev_zatoka = '"+vybrana_zatoka+"'";

     QSqlQuery *informace = new QSqlQuery;

     //použivám QString protože tyto hodnoty jsou pouze jedna a ne seznam

     informace->prepare(prikaz_1);
     informace->exec();
     informace->first();
     QString zatoka=informace->value(0).toString();
     informace->prepare(prikaz_2);
     informace->exec();
     informace->first();
     QString ostrov=informace->value(0).toString();
     informace->prepare(prikaz_3);
     informace->exec();
     informace->first();
     QString molo=informace->value(0).toString();
     informace->prepare(prikaz_4);
     informace->exec();
     informace->first();
     QString boje=informace->value(0).toString();
     informace->prepare(prikaz_5);
     informace->exec();
     informace->first();
     QString kotva=informace->value(0).toString();
     informace->prepare(prikaz_6);
     informace->exec();
     informace->first();
     QString obchod=informace->value(0).toString();
     informace->prepare(prikaz_7);
     informace->exec();
     informace->first();
     QString restaurace=informace->value(0).toString();

//Opravit zobrazení .... vypadá to na nic!


     QString vypsani ="Zátoka "+zatoka+" se nachází"
                      "na ostrove "+ostrov+"."
                      "Možnosti kotvení: "
                      "Stání u mola : "+molo+""
                      "Stání na bóji : "+boje+""
                      "Kotvení : "+kotva+""
                      "Dostupnost obchodů/restaurací:"
                      "Obchod : "+obchod+""
                      "Restaurace : "+restaurace+"";

     ui->textBrowser->clear();
     ui->textBrowser->setText(vypsani);
}
